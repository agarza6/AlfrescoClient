/**
 * Provides a unit tests for the web scripts of the REST bindings of the invitation service.
 * @since 3.1
 */
package org.alfresco.repo.web.scripts.invitation;
