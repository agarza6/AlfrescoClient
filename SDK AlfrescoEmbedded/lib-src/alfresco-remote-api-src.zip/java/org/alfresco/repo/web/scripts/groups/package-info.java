/**
 * Provides a unit tests for the web scripts of the REST bindings of the groups service.
 * @since 3.1
 */
package org.alfresco.repo.web.scripts.groups;
